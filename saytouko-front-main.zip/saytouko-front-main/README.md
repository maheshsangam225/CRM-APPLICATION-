# saytouko-front
A CRM application for the management of an institution (university)