import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-textbook',
  templateUrl: './textbook.component.html',
  styleUrls: ['./textbook.component.scss']
})
export class TextbookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
